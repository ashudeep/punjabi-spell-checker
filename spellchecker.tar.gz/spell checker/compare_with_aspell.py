# -*- coding: utf-8 -*-
h = codecs.open('correct.txt','a',encoding = 'utf-8')
with open ("aspell_results.txt", "r") as aspell_results:
	my_results = codecs.open('correct.txt','r',encoding = 'utf-8')
	for line1 in aspell_results:			
		line1=line1[:-1]
		if line1.split(' ')[0]=='&'||line1.split(' ')[0]=='#':
			h.write(line1.split(' ')[1]+" ")
			corrections=line1.split(':')[1].split(', ')
			
